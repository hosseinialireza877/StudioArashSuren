# Studio Arash Suren — Mobile Build v0.2

This is the Android prototype. It is designed so the APK can be built in the cloud without a PC.

## Build on GitHub using only an Android phone

1. Create a GitHub repository.
2. Upload the contents of this project.
3. Open the **Actions** tab.
4. Run **Build Android APK**.
5. When the workflow finishes, open the run and download the APK artifact.
6. Install the APK on the Android phone.

The current Create screen is a UI prototype. The real image-generation API/model router will be connected in the next development stage.

## Planned backend

Mobile app → Studio API → Model Router → Image/Video providers

API keys stay on the server, never inside the APK.
